# expired-team
Expired is an Android application that allows users to inventory their makeup collection and keep track of when their items are past their shelf life. Users are able to do this by scanning the barcodes of the items they purchased.  This project will hopefully expand into ios development in the near future. 
